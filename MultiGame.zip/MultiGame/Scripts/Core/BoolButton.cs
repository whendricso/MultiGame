﻿using UnityEngine;
using MultiGame;

namespace MultiGame {

	public class BoolButton : PropertyAttribute {

	}
}