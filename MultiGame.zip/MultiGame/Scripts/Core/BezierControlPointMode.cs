﻿using MultiGame;

namespace MultiGame {
	public enum BezierControlPointMode {
		Free,
		Aligned,
		Mirrored
	}
}