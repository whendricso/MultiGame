﻿using UnityEngine;

public class Line : MonoBehaviour {

	public Vector3 p0, p1;
}