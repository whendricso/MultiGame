﻿using MultiGame;

namespace MultiGame {
	public enum SplineMotorMode {
		Once,
		Loop,
		PingPong
	}
}